data.int
========

The integers.

* [basic](basic.lean) : the integers, with basic operations
* [order](order.lean) : the order relations and the sign function
* [div](div.lean) : div and mod
* [power](power.lean) 
* [gcd](gcd.lean) : gcd, lcm, and coprime    
* [bigops](bigops.lean)