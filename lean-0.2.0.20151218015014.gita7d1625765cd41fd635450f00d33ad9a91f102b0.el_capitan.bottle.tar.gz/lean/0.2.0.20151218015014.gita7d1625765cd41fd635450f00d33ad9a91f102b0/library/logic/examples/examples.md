logic.examples
==============

* [nuprl_examples](nuprl_examples.lean) : examples from "Logical investigations with the Nuprl Proof Assistant"
* [instances_test](instances_test.lean)
