theories.number_theory
======================

* [primes](primes.lean)
* [bezout](bezout.lean) : Bezout's theorem
* [prime_factorization](prime_factorization.lean) : prime divisors and multiplicity
* [irrational_roots](irrational_roots.lean) : irrationality of nth roots